package com.java.codingChallenge.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.codingChallenge.dao.OrderDao;
import com.java.codingChallenge.dao.OrderDaoImpl;

public class PlaceOrderMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter customer Id : ");
		int customerId = sc.nextInt();
		System.out.println("Enter product Id : ");
		int productId = sc.nextInt();
		System.out.println("Enter the quantity : ");
		int quantity = sc.nextInt();
		
		OrderDao o = new OrderDaoImpl();
		try {
			String msg = o.PlaceOrder(customerId, productId, quantity);
			System.out.println(msg);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
	}

}
