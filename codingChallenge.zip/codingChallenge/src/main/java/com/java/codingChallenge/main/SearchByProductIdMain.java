package com.java.codingChallenge.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.codingChallenge.dao.ProductDao;
import com.java.codingChallenge.dao.ProductsDaoImpl;
import com.java.codingChallenge.model.Products;

public class SearchByProductIdMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter product ID : ");
		int productId = sc.nextInt();
		ProductDao p = new ProductsDaoImpl();
		try {
			Products product = p.SearchByProductId(productId);
			if(product != null)
				System.out.println(product);
			else
				System.out.println("Product not found");
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

}
