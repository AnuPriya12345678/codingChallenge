package com.java.codingChallenge.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.codingChallenge.dao.CustomerDao;
import com.java.codingChallenge.dao.CustomerDaoImpl;
import com.java.codingChallenge.model.Customers;

public class AddCustomerMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Customers customer = new Customers();
		System.out.println("Enter the customer Id : ");
		customer.setCustomerId(sc.nextInt());
		System.out.println("Enter the first name : ");
		customer.setFirstName(sc.next());
		System.out.println("Enter the last name : ");
		customer.setLastName(sc.next());
		System.out.println("Enter the email : ");
		customer.setEmail(sc.next());
		System.out.println("Enter the password");
		customer.setPassword(sc.next());
		System.out.println("Enter the address : ");
		customer.setAddress(sc.next());
		CustomerDao s = new CustomerDaoImpl();
		try {
			String msg = s.AddCustomer(customer);
			System.out.println(msg);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
	}

}
