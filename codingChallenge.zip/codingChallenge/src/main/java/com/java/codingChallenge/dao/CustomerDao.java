package com.java.codingChallenge.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.codingChallenge.model.Customers;

public interface CustomerDao {
	
	List<Customers> ShowCustomers() throws ClassNotFoundException, SQLException;
	Customers SearchByCustomerId(int customerID) throws ClassNotFoundException, SQLException;
    Customers SearchByEmail(String email) throws ClassNotFoundException, SQLException;
    int AuthenticateCustomer(String firstName, String lastName, String password) throws ClassNotFoundException, SQLException;
	String AddCustomer(Customers customer) throws ClassNotFoundException, SQLException;
    
}
