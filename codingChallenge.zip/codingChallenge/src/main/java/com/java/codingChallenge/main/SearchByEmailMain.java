package com.java.codingChallenge.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.codingChallenge.dao.CustomerDao;
import com.java.codingChallenge.dao.CustomerDaoImpl;
import com.java.codingChallenge.model.Customers;

public class SearchByEmailMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the email : ");
		String email = sc.next();
		CustomerDao c = new CustomerDaoImpl();
		try {
			Customers customer = c.SearchByEmail(email);
			if(customer != null)
				System.out.println(customer);
			else
				System.out.println("Customer not found ...");
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}


	}

}
