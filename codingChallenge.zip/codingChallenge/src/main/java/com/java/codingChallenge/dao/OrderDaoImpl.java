package com.java.codingChallenge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.java.codingChallenge.model.Orders;
import com.java.codingChallenge.util.DBConnUtil;
import com.java.codingChallenge.util.DBPropertyUtil;

public class OrderDaoImpl implements OrderDao {
	
	Connection con;
	PreparedStatement pst;

	@Override
	public List<Orders> ShowCustomerOrders(int customerId) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectionString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM orders WHERE customerId = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, customerId);
		ResultSet rs = pst.executeQuery();
		List<Orders> orderList = new ArrayList<Orders> ();
		Orders order = null;
		while(rs.next())
		{
			order = new Orders();
			order.setOrderId(rs.getInt("orderId"));
			order.setCustomerId(rs.getInt("customerId"));
			order.setOrderDate(rs.getDate("orderDate"));
			order.setTotalAmount(rs.getDouble("totalAmount"));
			orderList.add(order);
		}
		return orderList;

		
	}

	@Override
	public String PlaceOrder(int customerId, int productId, int quantity) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectionString("db");
		con = DBConnUtil.getConnection(connectionString);
		
		String query1 = "SELECT price, stockQuantity FROM products WHERE productId = ?";
		pst = con.prepareStatement(query1);
		pst.setInt(1, productId);
		ResultSet rs = pst.executeQuery();
		rs.next();
		int price = rs.getInt(1);
		int stockQuantity = rs.getInt(2);
		
		if(quantity > stockQuantity)
			return "Stock is not sufficient";
		
		String query2 = "INSERT INTO orders(orderId, customerId, orderDate) VALUES(?,?,?)";
		pst = con.prepareStatement(query2);
		int orderId = GenerateOrderId();
		pst.setInt(1, orderId);
		pst.setInt(2, customerId);
		Date date = new Date();
		pst.setDate(3, new java.sql.Date(date.getTime()));
		pst.executeUpdate();
		
		String query3 = "INSERT INTO orderItems VALUES(?,?,?,?,?)";
		pst = con.prepareStatement(query3);
		pst.setInt(1, GenerateOrderItemId());
		pst.setInt(2, orderId);
		pst.setInt(3, productId);
		pst.setInt(4, quantity);
		int itemAmount = price * quantity;
		pst.setInt(5, itemAmount);
		pst.executeUpdate();
		
		String query4 = "SELECT SUM(itemAmount) FROM orderItems GROUP BY orderId HAVING orderId = ?";
		pst = con.prepareStatement(query4);
		pst.setInt(1, orderId);
		rs = pst.executeQuery();
		rs.next();
		int totalAmount = rs.getInt(1);
	    
		String query5 = "UPDATE orders SET totalAmount = ? WHERE orderId = ?";
		pst = con.prepareStatement(query5);
		pst.setInt(1, totalAmount);
		pst.setInt(2, orderId);
		pst.executeUpdate();
		
		String query6 = "SELECT email FROM customers WHERE customerId = ?";
		pst = con.prepareStatement(query1);
		pst.setInt(1, customerId);
		rs = pst.executeQuery();
		rs.next();
		String email = rs.getString(1);
		//This email can be used if it is a proper email address.
		//But it is a dummy value
		
		SendMail.mailSend("anupriya2.shanthi@gmail.com", "Status of order", "Order placed successfully");
		return "Order Placed";
		
	}
	
	public static int GenerateOrderId() throws ClassNotFoundException, SQLException
	{
		String connectionString = DBPropertyUtil.getConnectionString("db");
		Connection con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT max(orderId) FROM orders";
		PreparedStatement pst = con.prepareStatement(query);
		ResultSet rs = pst.executeQuery();
		rs.next();
		return rs.getInt(1)+1;
	}
	
	public static int GenerateOrderItemId() throws ClassNotFoundException, SQLException
	{
		String connectionString = DBPropertyUtil.getConnectionString("db");
		Connection con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT max(orderItemId) FROM orderItems";
		PreparedStatement pst = con.prepareStatement(query);
		ResultSet rs = pst.executeQuery();
		rs.next();
		return rs.getInt(1)+1;
	}
	
}
